#include<unistd.h>
void	ft_putchar(char c);

int	main(int argc, char **argv)
{
	ft_putchar('p');
	ft_putchar('u');
	ft_putchar('t');
	ft_putchar('c');
	ft_putchar('h');
	ft_putchar('a');
	ft_putchar('r');
	ft_putchar(' ');
	ft_putchar('!');
	ft_putchar('\n');

	return (0);
}
