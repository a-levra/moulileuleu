#include<unistd.h>
void	ft_print_alphabet(void);
int	main(int argc, char **argv)
{

	ft_print_alphabet();
	
	return (0);
}
