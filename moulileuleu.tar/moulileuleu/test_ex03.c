#include<unistd.h>
void	ft_print_numbers(void);
int	main(int argc, char **argv)
{
	ft_print_numbers();
	return (0);
}
