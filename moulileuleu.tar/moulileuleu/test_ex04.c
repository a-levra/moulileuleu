#include<unistd.h>
void	ft_is_negative(int n);
int	main(int argc, char **argv)
{

	ft_is_negative(-20000);
	ft_is_negative(20000);
	ft_is_negative(0);

	return (0);
}
