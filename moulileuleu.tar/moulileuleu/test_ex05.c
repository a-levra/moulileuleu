#include<unistd.h>
void	ft_print_comb(void);
int	main(int argc, char **argv)
{
	ft_print_comb();
	return (0);
}
