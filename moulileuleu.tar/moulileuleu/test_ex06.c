#include<unistd.h>
void	ft_print_comb2(void);
int	main(int argc, char **argv)
{
	ft_print_comb2();
	return (0);
}
