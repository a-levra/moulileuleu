#include<unistd.h>
void	ft_print_combn(void);
int	main(int argc, char **argv)
{
	ft_print_combn();
	return (0);
}
